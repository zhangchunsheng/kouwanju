game.fadeToSceneWithCityAndPlayer('City_fresh_village', function() {
    process.next();
    taskControl.execTask('MainLine');
});