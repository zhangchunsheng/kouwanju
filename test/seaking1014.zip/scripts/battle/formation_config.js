var formation_config = {
    player : {
        1 : {
            position: {
                x: 293,
                y: 450
            }
        },
        2 : {
            position: {
                x : 446,
                y : 411
            }
        },
        3 : {
            position: {
                x : 304,
                y : 365
            }
        },
        4 : {
            position: {
                x : 146,
                y : 400
            }
        },
        5 : {
            position: {
                x : 126,
                y : 483
            }
        },
        6 : {
            position: {
                x : 280,
                y : 540
            }
        },
        7 : {
            position: {
                x : 450,
                y : 500
            }
        }
    },
    enemy : {
        1 : {
            position: {
                x: 743,
                y: 335
            }
        },
        2 : {
            position: {
                x : 594,
                y : 411
            }
        },
        3 : {
            position: {
                x : 304,
                y : 365
            }
        },
        4 : {
            position: {
                x : 146,
                y : 400
            }
        },
        5 : {
            position: {
                x : 126,
                y : 483
            }
        },
        6 : {
            position: {
                x : 280,
                y : 540
            }
        },
        7 : {
            position: {
                x : 450,
                y : 500
            }
        }
    }
};