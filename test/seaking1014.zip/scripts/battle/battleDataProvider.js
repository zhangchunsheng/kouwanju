var battleDataProvider = (function() {

    var data;

    return {

        setBattleData : function(aData) {
            data = aData;
        },

        getBasicInfo : function(id) {

        }
    }

})();