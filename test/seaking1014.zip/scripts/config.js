var gameConfig = {

    "test" : false,

    "login" : true,

    "story" : true,

    "defaultScene" : "Scene_first_battle",
//    "defaultScene" : "City_fresh_village",

    "specialScenes" : {
        "Scene_first_battle" : true
    }
};