var playerPosition = (function() {

    return {

        'City_fresh_village' : {
            x : 1256,
            y : 1596
        },

        'City_liufengwan' : {
            x : 316,
            y : 2260
        },

        'City_shuangxingcheng' : {
            x : 210,
            y : 1564
        },
        'City_fresh_village_destroy' : {
            x : 1256,
            y : 1596
        },
        'City_tianwaicun' : {
            x : 728,
            y : 2188
        },
        'City_linghun' : {
            x : 522,
            y : 1320
        },
        'City_jiguangzhicheng' : {
            x : 568,
            y : 2900
        },
        'City_zhaoze' : {
            x : 2168,
            y : 2728
        },
        'City_shamogucheng' : {
            x : 728,
            y : 2012
        },
        'City_huoshanzhiguo' : {
            x : 2319,
            y : 1923
        },
        'City_bingxuechangcheng' : {
            x : 2454,
            y : 2938
        },
        'City_haishi' : {
            x : 1284,
            y : 966
        },

        'Ins_HaiYangLuDi' : {
            x : 360,
            y : 1650
        },
        'Ins_HaiYangGaoDi1' : {
            x:277,
            y:372
        }

    }

})();